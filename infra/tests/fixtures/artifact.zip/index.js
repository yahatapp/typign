import { createServer } from "node:http";
const [host, port] = process.env.AWS_LAMBDA_HTTP_ENDPOINT.split(":");
createServer((req, res) => res.end("fixture")).listen(Number(port), host);
